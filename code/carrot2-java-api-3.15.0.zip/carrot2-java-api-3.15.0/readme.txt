Carrot2 Java API
----------------

Carrot2 Java API lets you embed Carrot2 clustering in your Java software.
The API requires a Java Development Kit (JDK) version 1.7.0 or later.

See the examples/ directory for a number of copy-paste examples.

Run selected examples from command-line (ant or maven):
  ant
  mvn -Prun

Carrot2 Java API Javadocs available at:
http://download.carrot2.org/stable/javadoc

For more information, please refer to Carrot2 Manual:
http://download.carrot2.org/stable/manual



Build information
-----------------

Build version : 3.15.0
Build number  : C2-SOFTWARE-JA-233
Build time    : 2016-11-04 12:36:55
Built by      : bamboo
Build revision: 792c95863b8a42623267f1185fad82599f987d7b
